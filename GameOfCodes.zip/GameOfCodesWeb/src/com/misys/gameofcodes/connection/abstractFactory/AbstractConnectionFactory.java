package com.misys.gameofcodes.connection.abstractFactory;


public abstract class AbstractConnectionFactory 
{
	public abstract void createDatabaseConnection();
}
